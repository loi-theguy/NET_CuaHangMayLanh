﻿namespace DoAn_QuanLyMayLanh
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.chứcNăngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnQLSP = new System.Windows.Forms.ToolStripMenuItem();
            this.btnQLNV = new System.Windows.Forms.ToolStripMenuItem();
            this.btnQLKH = new System.Windows.Forms.ToolStripMenuItem();
            this.btnQLHD = new System.Windows.Forms.ToolStripMenuItem();
            this.btnQLNSX = new System.Windows.Forms.ToolStripMenuItem();
            this.btnQLNK = new System.Windows.Forms.ToolStripMenuItem();
            this.tàiKhoảnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnDangXuat = new System.Windows.Forms.ToolStripMenuItem();
            this.btnDoiMK = new System.Windows.Forms.ToolStripMenuItem();
            this.thốngKêToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnThongKeNV = new System.Windows.Forms.ToolStripMenuItem();
            this.btnThonKeHD = new System.Windows.Forms.ToolStripMenuItem();
            this.btnThongKeNK = new System.Windows.Forms.ToolStripMenuItem();
            this.btnThongKeKH = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.chứcNăngToolStripMenuItem,
            this.tàiKhoảnToolStripMenuItem,
            this.thốngKêToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(555, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // chứcNăngToolStripMenuItem
            // 
            this.chứcNăngToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnQLSP,
            this.btnQLNV,
            this.btnQLKH,
            this.btnQLHD,
            this.btnQLNSX,
            this.btnQLNK});
            this.chứcNăngToolStripMenuItem.Name = "chứcNăngToolStripMenuItem";
            this.chứcNăngToolStripMenuItem.Size = new System.Drawing.Size(77, 20);
            this.chứcNăngToolStripMenuItem.Text = "Chức năng";
            // 
            // btnQLSP
            // 
            this.btnQLSP.Name = "btnQLSP";
            this.btnQLSP.Size = new System.Drawing.Size(184, 22);
            this.btnQLSP.Text = "Quản lý sản phẩm";
            this.btnQLSP.Click += new System.EventHandler(this.btnQLSP_Click);
            // 
            // btnQLNV
            // 
            this.btnQLNV.Name = "btnQLNV";
            this.btnQLNV.Size = new System.Drawing.Size(184, 22);
            this.btnQLNV.Text = "Quản lý nhân viên";
            this.btnQLNV.Click += new System.EventHandler(this.btnQLNV_Click);
            // 
            // btnQLKH
            // 
            this.btnQLKH.Name = "btnQLKH";
            this.btnQLKH.Size = new System.Drawing.Size(184, 22);
            this.btnQLKH.Text = "Quản lý khách hàng";
            this.btnQLKH.Click += new System.EventHandler(this.btnQLKH_Click);
            // 
            // btnQLHD
            // 
            this.btnQLHD.Name = "btnQLHD";
            this.btnQLHD.Size = new System.Drawing.Size(184, 22);
            this.btnQLHD.Text = "Quản lý hóa đơn";
            this.btnQLHD.Click += new System.EventHandler(this.btnQLHD_Click);
            // 
            // btnQLNSX
            // 
            this.btnQLNSX.Name = "btnQLNSX";
            this.btnQLNSX.Size = new System.Drawing.Size(184, 22);
            this.btnQLNSX.Text = "Quản lý nhà sản xuất";
            this.btnQLNSX.Click += new System.EventHandler(this.btnQLNSX_Click);
            // 
            // btnQLNK
            // 
            this.btnQLNK.Name = "btnQLNK";
            this.btnQLNK.Size = new System.Drawing.Size(184, 22);
            this.btnQLNK.Text = "Quản lý nhập kho";
            this.btnQLNK.Click += new System.EventHandler(this.btnQLNK_Click);
            // 
            // tàiKhoảnToolStripMenuItem
            // 
            this.tàiKhoảnToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnDangXuat,
            this.btnDoiMK});
            this.tàiKhoảnToolStripMenuItem.Name = "tàiKhoảnToolStripMenuItem";
            this.tàiKhoảnToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.tàiKhoảnToolStripMenuItem.Text = "Tài khoản";
            // 
            // btnDangXuat
            // 
            this.btnDangXuat.Name = "btnDangXuat";
            this.btnDangXuat.Size = new System.Drawing.Size(145, 22);
            this.btnDangXuat.Text = "Đăng xuất";
            this.btnDangXuat.Click += new System.EventHandler(this.btnDangXuat_Click);
            // 
            // btnDoiMK
            // 
            this.btnDoiMK.Name = "btnDoiMK";
            this.btnDoiMK.Size = new System.Drawing.Size(145, 22);
            this.btnDoiMK.Text = "Đổi mật khẩu";
            this.btnDoiMK.Click += new System.EventHandler(this.btnDoiMK_Click);
            // 
            // thốngKêToolStripMenuItem
            // 
            this.thốngKêToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnThongKeNV,
            this.btnThonKeHD,
            this.btnThongKeNK,
            this.btnThongKeKH});
            this.thốngKêToolStripMenuItem.Name = "thốngKêToolStripMenuItem";
            this.thốngKêToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.thốngKêToolStripMenuItem.Text = "Thống kê";
            // 
            // btnThongKeNV
            // 
            this.btnThongKeNV.Name = "btnThongKeNV";
            this.btnThongKeNV.Size = new System.Drawing.Size(193, 22);
            this.btnThongKeNV.Text = "Nhân viên";
            this.btnThongKeNV.Click += new System.EventHandler(this.btnThongKeNV_Click);
            // 
            // btnThonKeHD
            // 
            this.btnThonKeHD.Name = "btnThonKeHD";
            this.btnThonKeHD.Size = new System.Drawing.Size(193, 22);
            this.btnThonKeHD.Text = "Các hóa đơn giao dịch";
            this.btnThonKeHD.Click += new System.EventHandler(this.btnThonKeHD_Click);
            // 
            // btnThongKeNK
            // 
            this.btnThongKeNK.Name = "btnThongKeNK";
            this.btnThongKeNK.Size = new System.Drawing.Size(193, 22);
            this.btnThongKeNK.Text = "Các lần nhập kho";
            this.btnThongKeNK.Click += new System.EventHandler(this.btnThongKeNK_Click);
            // 
            // btnThongKeKH
            // 
            this.btnThongKeKH.Name = "btnThongKeKH";
            this.btnThongKeKH.Size = new System.Drawing.Size(193, 22);
            this.btnThongKeKH.Text = "Khách hàng";
            this.btnThongKeKH.Click += new System.EventHandler(this.btnThongKeKH_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(555, 314);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Main";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Main_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem chứcNăngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem btnQLSP;
        private System.Windows.Forms.ToolStripMenuItem btnQLNV;
        private System.Windows.Forms.ToolStripMenuItem btnQLKH;
        private System.Windows.Forms.ToolStripMenuItem btnQLHD;
        private System.Windows.Forms.ToolStripMenuItem btnQLNSX;
        private System.Windows.Forms.ToolStripMenuItem btnQLNK;
        private System.Windows.Forms.ToolStripMenuItem tàiKhoảnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem btnDangXuat;
        private System.Windows.Forms.ToolStripMenuItem btnDoiMK;
        private System.Windows.Forms.ToolStripMenuItem thốngKêToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem btnThongKeNV;
        private System.Windows.Forms.ToolStripMenuItem btnThonKeHD;
        private System.Windows.Forms.ToolStripMenuItem btnThongKeNK;
        private System.Windows.Forms.ToolStripMenuItem btnThongKeKH;

    }
}

